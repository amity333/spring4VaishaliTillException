package com.cg.tms.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.tms.dto.Login;
import com.cg.tms.dto.Trainee;
import com.cg.tms.service.TraineeService;

@Controller
public class TraineeController {
	@Autowired
	TraineeService tservice;

	public TraineeService getTservice() {
		return tservice;
	}

	public void setTservice(TraineeService tservice) {
		this.tservice = tservice;
	}

	@RequestMapping(value = "/ShowLoginPage")
	public String login(Model model) {
		Login log = new Login();
		log.setUserName("Enter the Username");
		log.setUserPass("Enter the Password");
		model.addAttribute("logg", log);
		return "Login";
	}

	@RequestMapping(value = "/ValidatedUser")
	public String validateUser(@ModelAttribute("logg") @Valid Login lgg, BindingResult result, Model model) {
		// System.out.println("Validate USer="+lgg);
		// String unm=lgg.getUserName();
		// System.out.println(unm+"321321");
		if (result.hasErrors()) {
			return "Login";
		} else {
			// Login tLog=tservice.getTraineeByUserName(unm);
			if (tservice.validateTrainee(lgg)) {
				return "Success";
			} else {
				model.addAttribute("MsgObj", "check the Password");
				return "Login";
			}
		}
	}

	@RequestMapping(value = "/AddTrainee")
	public String addTrainee(Trainee t, Model model) {

		ArrayList<String> skillList = new ArrayList<String>();
		skillList.add("Java");
		skillList.add("Oracle");
		skillList.add("BI");
		model.addAttribute("skillListObj", skillList);
		t = new Trainee();

		model.addAttribute("t", t);

		// tservice.addTrainee(t);

		return "AddTrainee";

	}

	@RequestMapping(value = "/AddTraineeDetails")
	public String addTraineeInDB(@ModelAttribute("t") @Valid Trainee t, BindingResult result, Model model) {
		System.out.println("hellllllllooooooooooo");
		if (result.hasErrors()) {
			System.out.println("fuckkkkkkkkkkkkkk");
			ArrayList<String> skillList = new ArrayList<String>();
			skillList.add("Java");
			skillList.add("Oracle");
			skillList.add("BI");
			model.addAttribute("skillListObj", skillList);
			return "AddTrainee";
		} else {

			System.out.println("in add trainee" + t);

			tservice.addTrainee(t);
			return "addSuccess";
		}
	}

	@RequestMapping(value = "/DeleteTrainee")
	public String deleteTrainee(Model model) {
		Trainee t = new Trainee();
		model.addAttribute("flag", false);
		model.addAttribute("t", t);
		return "deleteForm";
	}

	@RequestMapping(value = "/deleteSuccess")
	public String deleteFromDatabase(@ModelAttribute("t") Trainee t, Model model) {
		int id = t.getTraineeId();
		Trainee ft = tservice.getTraineeById(id);
		if (ft != null) {
			System.out.println(ft + "inside ctrl deltefrodb");
			tservice.deleteTrainee(ft);
			model.addAttribute("flag", true);
			model.addAttribute("t", ft);
			return "deleteForm";
		} else {
			model.addAttribute("eMsg", "Id does not exist");
			model.addAttribute("flag", false);
			return "deleteForm";
		}
	}

	@RequestMapping(value = "/ModifyTrainee")
	public String updateTrainee(Model model) {

		Trainee t = new Trainee();
		model.addAttribute("flag", false);
		model.addAttribute("t", t);
		return "UpdateFormId";
	}

	@RequestMapping(value = "/update1")
	public String updateTraineeForm(@ModelAttribute("t") Trainee t, Model model) {
		Trainee ft = tservice.getTraineeById(t.getTraineeId());
		if (ft != null) {
			ArrayList<String> skillList = new ArrayList<String>();
			skillList.add("Java");
			skillList.add("Oracle");
			skillList.add("BI");
			model.addAttribute("skillListObj", skillList);
			model.addAttribute("ft", ft);
			model.addAttribute("flag", true);
			System.out.println("insideUpdate Form " + ft);
			return "UpdateFormId";
		} else {
			model.addAttribute("flag", false);
			model.addAttribute("eMsg", "Id does not exist");
			return "UpdateFormId";
		}
	}

	@RequestMapping(value = "/updateinDB")
	public String updateTraineeInDb(@ModelAttribute("ft") Trainee t, Model model) {

		System.out.println(t);
		model.addAttribute("ft", t);
		//model.addAttribute("flag", true);
		tservice.updateTrainee(t);
		model.addAttribute("t",t);
		return "updateSuccess";
	}

	@RequestMapping(value = "/RetrieveTrainee")
	public String retrieveSingle(Trainee t, Model model) {
		t = new Trainee();
		model.addAttribute("flag", false);
		model.addAttribute("t", t);
		return "singleTrainee";
	}

	@RequestMapping(value = "/getById")
	public String getByID(@ModelAttribute("t") Trainee t, Model model) {
		Trainee ft = tservice.getTraineeById(t.getTraineeId());
		if (ft != null) {
			model.addAttribute("flag", true);
			model.addAttribute("t", ft);
			return "singleTrainee";
		} else {
			model.addAttribute("eMsg", "Id does not exist");
			model.addAttribute("flag", false);
			return "singleTrainee";
		}
	}

	@RequestMapping(value = "/RetrieveAllTrainee")
	public String getAllUser(Model model) {
		ArrayList<Trainee> tr = tservice.getAllTrainee();
		model.addAttribute("tr", tr);
		return "ShowAll";
	}

}
