package com.cg.tms.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;

import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

import com.cg.tms.dto.Login;
import com.cg.tms.dto.Trainee;
@Component
@Transactional
public class TraineeDaoImpl implements TraineeDao
{
	@PersistenceContext
	EntityManager em;
	
	@Override
	public Login getTraineeByUserName(String unm) {
		Login logg=em.find(Login.class, unm);
		/*logg.setUserName("b");
		logg.setUserPass("a");*/
		//System.out.println("4444444444444444444444444444444"+logg);
		return logg;
	}

	@Override
	public void addTrainee(Trainee t) {
		System.out.println("inside DAo IMPL");
		em.persist(t);
	}

	@Override
	public void deleteTrainee(Trainee t) {
		/*em.remove(em.contains(t) ? t : em.merge(t));*/
		String qstr="DELETE FROM Trainee mob where mob.traineeId=:id ";
		int id=t.getTraineeId();
		Query query=em.createQuery(qstr);
		query.setParameter("id", id);
		
		query.executeUpdate();
	}

	@Override
	public Trainee getTraineeById(int id) {
		Trainee t=em.find(Trainee.class, id);
		return t;
	}

	@Override
	public void updateTrainee(Trainee t) {
		String qstr="UPDATE Trainee mob SET  mob.traineeName = :name , mob.traineeDomain= :td,  mob.traineeLocation= :tl where mob.traineeId = :id";
		System.out.println("inside Dao impl=>"+t);
		System.out.println(t.getTraineeId());
		Query query=em.createQuery(qstr);
		query.setParameter("id", t.getTraineeId());
		query.setParameter("name", t.getTraineeName());
		query.setParameter("td",t.getTraineeDomain() );
		query.setParameter("tl", t.getTraineeLocation());
		query.executeUpdate();
	}

	@Override
	public ArrayList<Trainee> getAllTrainee() {
		String selectUserQry="Select reg from Trainee reg";
		TypedQuery<Trainee> tq= em.createQuery(selectUserQry,Trainee.class);
		ArrayList <Trainee> tr=(ArrayList)tq.getResultList();
		return tr;
	}

}
