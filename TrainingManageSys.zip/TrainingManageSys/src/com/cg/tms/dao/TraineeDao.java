package com.cg.tms.dao;

import java.util.ArrayList;

import com.cg.tms.dto.Login;
import com.cg.tms.dto.Trainee;

public interface TraineeDao 
{	
	public Login getTraineeByUserName(String unm);
	public void addTrainee(Trainee t);
	public void deleteTrainee(Trainee t);
	public Trainee getTraineeById(int id);
	public void updateTrainee(Trainee t);
	public ArrayList<Trainee> getAllTrainee();
}
